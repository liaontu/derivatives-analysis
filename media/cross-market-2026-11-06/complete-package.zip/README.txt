FlowScope 三市場觀察 EP.01｜清新文青版
先開啟 index.html 查看影片、圖卡及章節；如瀏覽器不支援本機章節跳轉，直接用播放器開啟MP4。
完整影片：full-video.mp4，13:57，1920×1080，30fps。
直式精華：vertical-highlights.mp4，01:22，1080×1920，30fps。
圖卡：card-01.png 至 card-12.png，1080×1350；順序不可倒置。替代文字另附。
字幕：captions.srt／vtt為完整影片；highlights-captions.srt／vtt為直式精華。
旁白：narration.mp3；AI合成聲線。字幕依實際音訊與停頓定位，不是逐字強制對齊。
封面：LandscapeCover.png、PortraitCover.png、youtube-thumbnail.jpg。
文案：貼文與影片文案.txt、platform-copy.json、chapters.txt。
方法、來源、證據：資料與方法.txt、facts.json、source-receipts.json及驗證結果。
素材可供本次發布使用；本次只製作與交付，尚未發布到任何社群帳號。
不含新增付費資料、語音API或第三方背景音樂。
