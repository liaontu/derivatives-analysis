import React from 'react';
import {AbsoluteFill,Sequence,staticFile,useCurrentFrame,useVideoConfig,interpolate} from 'remotion';
import {Audio} from '@remotion/media';
import {loadFont} from '@remotion/fonts';
import facts from './facts.json';
import content from './content.json';
import timeline from './timeline.json';
import captionData from './captions.json';
import type {Caption} from '@remotion/captions';
const captions:Caption[]=captionData;
loadFont({family:'Noto Sans TC',url:staticFile('NotoSansTC.ttf'),weight:'100 900'});
const C={paper:'#FBFCF8',ink:'#334B48',green:'#467563',red:'#A75C58',gold:'#607D94',muted:'#697873',line:'#E2EAE4',white:'#FFFFFF',sage:'#EDF3ED',sky:'#EDF3F7',peach:'#FAEEE5'};
const fmt=(n:number,d=0)=>n.toLocaleString('en-US',{minimumFractionDigits:d,maximumFractionDigits:d});
const pct=(n:number)=>`${n>0?'+':''}${n.toFixed(2)}%`;
const panel:React.CSSProperties={background:C.white,border:'1px solid '+C.line,borderRadius:16,padding:34};
const Text=({children,size=38,color=C.ink}:any)=><div style={{fontSize:size,color,lineHeight:1.6,fontWeight:400}}>{children}</div>;
const Stat=({label,value,note,color=C.ink,small=false}:any)=><div style={{...panel,background:color===C.gold?C.sky:color===C.red?C.peach:C.sage,border:'none',flex:1,minWidth:0,display:'flex',flexDirection:'column',justifyContent:'center'}}><Text size={small?30:34} color={C.muted}>{label}</Text><div style={{fontSize:small?64:88,fontWeight:550,lineHeight:1.35,color,letterSpacing:-1,overflowWrap:'anywhere'}}>{value}</div>{note&&<Text size={small?28:32}>{note}</Text>}</div>;
const Grid=({children,p=false}:any)=><div style={{display:'grid',gridTemplateColumns:p?'1fr':'1fr 1fr',gap:32,height:'100%'}}>{children}</div>;
const Steps=({items,p=false}:any)=><div style={{display:'grid',gridTemplateColumns:p?'1fr':'repeat(3,1fr)',gap:32,height:'100%'}}>{items.map((x:string[],i:number)=><div key={i} style={{...panel,background:C.sage,border:'none',display:'flex',flexDirection:p?'row':'column',alignItems:p?'center':undefined,justifyContent:'center',gap:p?24:14}}><span style={{color:C.gold,fontSize:p?36:40,fontWeight:450}}>0{i+1}</span><div><Text size={p?38:46}><span style={{fontWeight:550}}>{x[0]}</span></Text><Text size={p?30:34}>{x[1]}</Text></div></div>)}</div>;

function PriceChart({p=false,progress=1}:{p?:boolean;progress?:number}){
 const w=p?920:1590,h=p?430:370,pad=65,lo=-22,hi=6;
 const x=(i:number)=>pad+i*(w-2*pad)/(facts.daily.length-1);const y=(v:number)=>h-pad-(v-lo)/(hi-lo)*(h-pad-25);
 const series=[{key:'spot' as const,color:C.green,base:facts.cash.baseline},{key:'future' as const,color:C.gold,base:facts.tx.baseline}];
 return <svg viewBox={`0 0 ${w} ${h}`} width="100%" height="100%">
  {[-20,-10,0].map(v=><g key={v}><line x1={pad} x2={w-pad} y1={y(v)} y2={y(v)} stroke={C.line} strokeWidth={2}/><text x={pad-10} y={y(v)+9} textAnchor="end" fontSize={25} fill={C.muted}>{v}%</text></g>)}
  <defs><clipPath id={'price-'+String(p)}><rect x={0} y={0} width={w*progress} height={h}/></clipPath></defs>
  {series.map(s=><polyline key={s.key} clipPath={`url(#price-${String(p)})`} points={facts.daily.map((r,i)=>`${x(i)},${y((r[s.key]/s.base-1)*100)}`).join(' ')} fill="none" stroke={s.color} strokeWidth={5} strokeLinejoin="round" strokeDasharray={s.key==='future'?'12 7':undefined}/>)}
  {[0,5,10,15,20,24].map(i=><text key={i} x={x(i)} y={h-20} textAnchor="middle" fontSize={25} fill={C.muted}>{facts.daily[i].date.slice(5).replace('-','/')}</text>)}
 </svg>;
}
function WeekBars({p=false,progress=1}:any){
 return <div style={{height:'100%',display:'flex',flexDirection:'column',justifyContent:'space-between',gap:12}}>{facts.weeks.map(w=><div key={w.start} style={{display:'grid',gridTemplateColumns:p?'230px 1fr 170px':'330px 1fr 200px',gap:25,alignItems:'center'}}><Text size={p?30:36}>{w.start.slice(5).replace('-','/')}～{w.end.slice(5).replace('-','/')}</Text><div style={{background:C.sage,height:p?26:24,borderRadius:6}}><div style={{width:`${Math.abs(w.spotPct)/13*100*progress}%`,height:'100%',background:w.spotPct>0?C.green:C.red,borderRadius:6}}/></div><div style={{fontSize:p?38:44,fontWeight:550,color:w.spotPct>0?C.green:C.red,textAlign:'right'}}>{pct(w.spotPct)}</div></div>)}<Text size={p?29:30} color={C.muted}>加權指數每週價格變動；柱長代表變動幅度。</Text></div>;
}
function Breadth({p=false,progress=1}:any){return <div style={{display:'flex',flexDirection:'column',justifyContent:'center',gap:40,height:'100%'}}>{facts.breadth.map(g=><div key={g.market}><div style={{display:'flex',justifyContent:'space-between',alignItems:'baseline'}}><Text size={p?42:46}>{g.label}樣本</Text><div style={{fontSize:p?54:68,fontWeight:600,color:C.red}}>{fmt(g.down)} <span style={{fontSize:30,color:C.muted}}>／ {fmt(g.valid)} 檔下跌</span></div></div><div style={{height:26,marginTop:18,background:C.sage,borderRadius:9,overflow:'hidden'}}><div style={{width:`${g.down/g.valid*100*progress}%`,height:'100%',background:C.red}}/></div></div>)}<Text size={p?30:32} color={C.muted}>分母為排除事件與缺價後可比較股票，非完整歷史成分。</Text></div>}
function Inst({p=false}:any){return <Grid p={p}>{['外資及陸資','投信'].map(name=>{const v=facts.institutions.find(x=>x.investor===name)!;return <div key={name} style={{...panel,background:name==='投信'?C.sage:C.peach,border:'none',padding:p?28:36,display:'flex',flexDirection:'column',justifyContent:'center',gap:p?10:14}}><Text size={p?34:46}>{name==='外資及陸資'?'外資及陸資｜淨空':'投信｜淨多'}</Text><Text size={p?30:48} color={C.muted}>{fmt(v.base)} →</Text><div style={{fontSize:p?66:96,lineHeight:1.15,fontWeight:600,color:v.last<0?C.red:C.green}}>{v.last>0?'+':''}{fmt(v.last)}</div><Text size={p?28:36}>口；期間變化 {v.change>0?'+':''}{fmt(v.change)} 口</Text></div>})}</Grid>}
function Totals({kind,p=false}:any){const a=facts.options.base,b=facts.options.last;return <Grid p={p}><Stat small={p} label={kind==='rollover'?'固定 TX 202611 OI（口）':'買權 C 未平倉（口）'} value={kind==='rollover'?fmt(facts.tx.oi):fmt(b.callOi)} note={`9/30：${fmt(kind==='rollover'?facts.tx.baseOi:a.callOi)} 口`} color={C.ink}/><Stat small={p} label={kind==='rollover'?'全存續月份 TX OI（口）':'賣權 P 未平倉（口）'} value={kind==='rollover'?fmt(facts.txOi.at(-1)!.oi):fmt(b.putOi)} note={`9/30：${fmt(kind==='rollover'?facts.txOi[0].oi:a.putOi)} 口`} color={C.gold}/></Grid>}
function Case({code,p=false}:any){const s=facts.stocks.find(x=>x.code===code)!;return <div style={{height:'100%',display:'flex',flexDirection:'column',gap:26}}><Text size={p?42:46}>{s.code} {s.name}｜9/30 → 11/06</Text><Grid p={p}><Stat small={p} label="現股價格變動" value={pct(s.returnPct)} color={C.red} note={`${fmt(s.base)} → ${fmt(s.last)} 元`}/><Stat small={p} label={`${s.future.contract} ${s.future.month}`} value={pct(s.future.returnPct)} color={C.red} note={`${fmt(s.future.base)} → ${fmt(s.future.last)} 元`}/></Grid></div>}
export function Visual({kind,p=false,progress=1}:any){
 const ratio=facts.options,co=facts.correlations[0];
 switch(kind){
 case 'cover':return <div style={{height:'100%',display:'flex',flexDirection:'column',justifyContent:'center',gap:30}}><div style={{display:'flex',gap:24}}><Stat small={p} label="加權指數期間變動" value={pct(facts.cash.returnPct)} color={C.red}/><Stat small={p} label="大台 TX 202611" value={pct(facts.tx.returnPct)} color={C.red}/></div><Text size={p?40:50}>價格同步走弱，法人部位分歧。<br/>把證據放回正確的比較條件。</Text></div>;
 case 'scope':return <Steps p={p} items={[["固定日期","10/01～11/06；9/30 為基準"],["固定契約","大台 TX 202611；不拼接月份"],["固定單位","股、元、口，各自比較"]]}/>;
 case 'prices':return <div style={{height:'100%',display:'flex',flexDirection:'column'}}><div style={{display:'flex',justifyContent:'space-between'}}><Text size={p?32:36}>━ 現股 {pct(facts.cash.returnPct)}</Text><Text size={p?32:36} color={C.gold}>┄ TX {pct(facts.tx.returnPct)}</Text></div><div style={{flex:1,minHeight:0}}><PriceChart p={p} progress={progress}/></div><Text size={28} color={C.muted}>橫軸為交易日等距；現期收盤時點不同。</Text></div>;
 case 'direction':return <Grid p={p}><Stat label="同日同方向" value="22 / 24" note="個交易日"/><Stat label="需要另外驗證" value="下一天？" note="今天同步，不等於明天可預測" color={C.gold}/></Grid>;
 case 'weeks':return <WeekBars p={p} progress={progress}/>;
 case 'drawdown':return <Grid p={p}><Stat label="從本期收盤高點回落" value={pct(facts.cash.maxPriceDrawdownPct)} color={C.red} note="最高收盤：2026/10/06"/><div style={panel}><Text size={p?43:54}>期間報酬與回撤<br/>回答不同問題</Text><div style={{marginTop:32}}><Text size={p?32:38}>期間報酬：相對 9/30<br/>回撤：相對之前的收盤高點<br/>不涵蓋盤中最低點</Text></div></div></Grid>;
 case 'breadth':return <Breadth p={p} progress={progress}/>;
 case 'medians':return <Grid p={p}>{facts.breadth.map(g=><Stat key={g.market} label={g.label+'樣本中位數'} value={pct(g.median)} color={C.red} note={`${fmt(g.valid)} 檔；等權價格變動`}/>)}</Grid>;
 case 'volume':return <div style={{height:'100%',display:'flex',flexDirection:'column',gap:24}}><Grid p={p}><Stat small={p} label="現股日均成交金額" value={pct(facts.cashAmountWeekChangePct)} color={C.green} note="11/02～11/06，較前週"/><Stat small={p} label="TX 202611 日均成交口數" value={pct(facts.txVolumeWeekChangePct)} color={C.green} note="11/02～11/06，較前週"/></Grid><Text size={p?34:38}>量增＝交易更活躍；尚不能辨識交易動機。</Text></div>;
 case 'volumeMeaning':return <Steps p={p} items={[["成交量","一天交易了多少"],["未平倉量","還有多少契約未結束"],["交易動機","需要額外證據，不能從量推定"]]}/>;
 case 'foreign':return <Inst p={p}/>;
 case 'exposure':return <Steps p={p} items={[["投資人類別","許多帳戶的合計"],["跨市場部位","現股、大小台、選擇權各有風險"],["尚未配對","不能還原個人的避險策略"]]}/>;
 case 'cohorts':return <div style={{height:'100%',display:'flex',flexDirection:'column',gap:26}}><Text size={p?35:40}>上市｜全期外資累計買超組</Text><Grid p={p}><Stat small={p} label="仍然下跌" value="501 / 578" color={C.red} note="檔；全期法人資料完整"/><Stat small={p} label="價格變動中位數" value={pct(facts.cohorts[0].median)} color={C.red} note="事後分組，不是先知名單"/></Grid></div>;
 case 'cohortLimits':return <Steps p={p} items={[["全期累加","期末才知道組別"],["同期觀察","描述買超與價格的關係"],["尚未驗證","事前規則及樣本外表現"]]}/>;
 case 'oi':return <Steps p={p} items={[["成交量","當天買賣成交的口數"],["未平倉 OI","尚未結束的契約數量"],["同一口契約","同時有多方與空方"]]}/>;
 case 'rollover':return <div style={{height:'100%',display:'flex',flexDirection:'column',gap:24}}><Totals p={p} kind="rollover"/><Text size={p?31:36}>單月由遠月轉近月的增量，包含移轉部位。</Text></div>;
 case 'expiry':return <Grid p={p}><Stat label="C／P 未平倉核對" value="25 / 25" note="日期一致；含 9/30 基準日"/><div style={panel}><Text size={p?42:48}>依官方結算日排除</Text><div style={{marginTop:24}}><Text size={p?34:38}>未來部位：排除已到期<br/>當日成交：保留歷史數字<br/>原始來源：另存可追溯</Text></div></div></Grid>;
 case 'pcr':return <div style={{height:'100%',display:'flex',flexDirection:'column',gap:25}}><div style={{fontSize:p?62:76,fontWeight:600,color:C.gold}}>{fmt(ratio.base.oiRatio,2)}% → {fmt(ratio.last.oiRatio,2)}%</div><div style={{flex:1}}><Totals p={p} kind="pcr"/></div><Text size={p?27:30}>排除到期後的 C／P 未平倉量；比率不代表買方方向。</Text></div>;
 case 'fixedpcr':{const m=facts.maturities.find(v=>v.month==='202611')!;return <Grid p={p}><Stat label="同到期別 P/C" value="114.62%" note="2026/09/30"/><Stat label="同到期別 P/C" value={`${fmt(m.pc,2)}%`} note="2026/11/06" color={C.gold}/></Grid>}
 case 'optionMeaning':return <Steps p={p} items={[["買進買權","買方的權利與風險"],["賣出買權","賣方的義務與風險"],["組合部位","可能只是策略的一部分"]]}/>;
 case 'correlation':return <div style={{height:'100%',display:'flex',flexDirection:'column',gap:28}}><Grid p={p}><Stat small={p} label="期貨當日 → 現股當日" value={fmt(co.same.r,3)} note={`相關係數；n＝${co.same.n}`} color={C.ink}/><Stat small={p} label="期貨當日 → 現股隔日" value={fmt(co.next.r,3)} note={`相關係數；n＝${co.next.n}`} color={C.gold}/></Grid><Text size={p?34:39}>24 日短樣本，尚未證明預測能力。</Text></div>;
 case 'correlationLimits':return <Steps p={p} items={[["樣本短","同一段市場環境"],["線性關係","不代表所有可能關係"],["後續檢驗","固定規則，再看新資料"]]}/>;
 case 'tsmc':return <Case code="2330" p={p}/>;
 case 'stockcases':return <div style={{display:'flex',flexDirection:'column',gap:32,height:'100%',justifyContent:'center'}}>{facts.stocks.filter(s=>s.code!=='2330').map(s=><div key={s.code} style={{...panel,display:'grid',gridTemplateColumns:p?'1fr 1fr':'1fr 1fr 1fr',gap:18}}><Text size={p?38:44}><span style={{fontWeight:550}}>{s.name}</span></Text><Text size={p?36:42} color={C.red}>現股 {pct(s.returnPct)}</Text><Text size={p?36:42} color={C.red}>股期 {pct(s.future.returnPct)}</Text></div>)}<Text size={p?30:34}>同方向，幅度也不同；不以大盤期貨取代個股期貨。</Text></div>;
 case 'sparse':return <div style={{height:'100%',display:'flex',flexDirection:'column',gap:24}}><Grid p={p}><Stat small={p} label="本期至少一次成交" value={`${facts.stockOptionTradedPeriod} / ${facts.stockOptionCount}`} note="個股選擇權標的"/><Stat small={p} label="11/06 當日有成交" value={`${facts.stockOptionTradedLatest} / ${facts.stockOptionCount}`} note="一般交易時段" color={C.gold}/></Grid><Text size={p?34:40}>沒有成交，不拿舊價格冒充當日資訊。</Text></div>;
 case 'warrantBoundary':return <Steps p={p} items={[["先比條款","履約價、比例、期限"],["再看量價","成交日與報價時點"],["分清身分","發行商造市不等於客戶買賣"]]}/>;
 case 'known':return <Steps p={p} items={[["價格","現期同步走弱，最新週跌幅擴大"],["廣度","多數可比較股票下跌"],["部位","法人分歧；買權 OI 擴張"]]}/>;
 case 'followup':return <Steps p={p} items={[["價格與廣度","反彈是否伴隨更多股票回升？"],["量與法人","下跌量是否減弱、淨空是否縮小？"],["選擇權","同到期別的買賣權結構如何變？"]]}/>;
 case 'method':return <Steps p={p} items={[["資料期間","24 個交易日；只支持短期觀察"],["排除與缺值","公司行動排除；缺列不補零"],["可追溯","凍結報告、來源、版本與雜湊"]]}/>;
 case 'end':return <div style={{height:'100%',display:'flex',flexDirection:'column',justifyContent:'center',gap:32}}><Text size={p?58:86}>對齊日期 → 分開口徑<br/>留下問題 → 持續驗證</Text><Text size={p?36:46}>收藏這份觀察，讓新資料來檢查。</Text><Text size={30} color={C.muted}>價格未還原為含息報酬；不推定單一大戶策略。</Text></div>;
 default:return null;
 }
}


function PaperDetail({portrait=false,cover=false}:{portrait?:boolean;cover?:boolean}){
 return <svg aria-hidden="true" viewBox="0 0 500 500" style={{position:'absolute',width:cover?(portrait?540:650):240,height:cover?(portrait?540:650):240,right:cover?(portrait?-80:-70):-60,top:cover?(portrait?990:310):-75,pointerEvents:'none',opacity:cover?1:.65}}>
  <circle cx="305" cy="250" r="175" fill={C.sage}/><circle cx="180" cy="340" r="106" fill={C.sky}/><circle cx="375" cy="112" r="56" fill={C.peach}/>
  <g fill="none" stroke="#A6BBB0" strokeWidth="2.4" strokeLinecap="round"><path d="M200 440 Q300 300 290 90"/><path d="M281 228 Q203 222 205 158 Q276 159 281 228"/><path d="M281 290 Q351 287 367 219 Q295 222 281 290"/><path d="M251 360 Q183 340 175 286 Q247 289 251 360"/><path d="M289 173 Q346 148 337 99 Q292 109 289 173"/></g>
 </svg>;
}
const Brand=({label,number,portrait=false}:{label:string;number?:string;portrait?:boolean})=><div style={{display:'flex',justifyContent:'space-between',alignItems:'center',fontSize:portrait?25:26,color:C.muted,letterSpacing:1.3,position:'relative'}}><span style={{display:'flex',alignItems:'center',gap:14}}><span style={{width:10,height:10,borderRadius:'50%',background:'#93B0A0'}}/><span style={{fontWeight:500}}>FlowScope</span><span style={{color:C.line}}> / </span><span>{label}</span></span><span style={{fontSize:portrait?23:25}}>{number}</span></div>;

export function Scene({index}:{index:number}){
 const frame=useCurrentFrame(),{fps}=useVideoConfig();const s=content.scenes[index];
 const progress=interpolate(frame,[0,1.6*fps],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp'});
 return <AbsoluteFill style={{background:C.paper,fontFamily:'Noto Sans TC',color:C.ink,padding:'48px 104px'}}>
 <PaperDetail/><Brand label="三市場觀察 EP.01" number={`2026.10.01—11.06　　${String(index+1).padStart(2,'0')} / 30`}/>
 <div style={{fontSize:26,color:C.gold,marginTop:36,fontWeight:400,letterSpacing:1.5}}>{s.kicker}</div>
 <div style={{fontSize:64,fontWeight:550,lineHeight:1.35,marginTop:16,letterSpacing:1,whiteSpace:'pre-line',position:'relative'}}>{s.title.replace('\n','　')}</div>
 <div data-body style={{position:'absolute',left:104,right:104,top:310,height:455,opacity:interpolate(frame,[0,12],[.35,1],{extrapolateRight:'clamp'})}}><Visual kind={s.kind} progress={progress}/></div>
 <div data-method style={{position:'absolute',left:104,right:104,top:803,fontSize:26,color:C.muted,borderTop:'1px solid '+C.line,paddingTop:20}}>{s.callout}</div>
 </AbsoluteFill>;
}
function CaptionLayer({portrait=false,items=captions}:{portrait?:boolean;items?:Caption[]}){
 const frame=useCurrentFrame(),{fps}=useVideoConfig();const ms=frame/fps*1000;const c=items.find(v=>v.startMs<=ms&&v.endMs>ms);
 if(!c)return null;
 return <div data-caption style={{position:'absolute',left:portrait?80:175,right:portrait?80:175,bottom:portrait?205:37,minHeight:112,background:'#FFFFFF',color:C.ink,border:'1px solid '+C.line,borderRadius:16,padding:portrait?'22px 26px':'14px 30px',textAlign:'center',fontFamily:'Noto Sans TC',fontSize:portrait?46:40,lineHeight:1.45,whiteSpace:'pre-line',fontWeight:450}}>{c.text}</div>;
}
export const Film=()=> <AbsoluteFill>
 {timeline.scenes.map(s=><Sequence key={s.index} name={content.scenes[s.index].title.replace('\n',' ')} from={s.from} durationInFrames={s.durationInFrames}><Scene index={s.index}/></Sequence>)}
 <Audio src={staticFile(timeline.narration)}/><CaptionLayer/>
 </AbsoluteFill>;
export function Card({number}:{number:number}){const index=content.cardScenes[number-1],s=content.scenes[index];const titles:Record<number,string>={6:'外資淨空擴大\n投信淨多增加',7:'外資買超組\n多數股價仍下跌',9:'P/C 下降\n先看買權與賣權',11:'有選擇權商品\n不代表每天有成交'};return <AbsoluteFill style={{background:C.paper,fontFamily:'Noto Sans TC',color:C.ink,padding:'60px 80px'}}>
 <PaperDetail portrait/><Brand portrait label="三市場觀察" number={`${String(number).padStart(2,'0')} / 12`}/>
 <div style={{fontSize:25,color:C.gold,marginTop:44,fontWeight:400,letterSpacing:1.3}}>{s.kicker}</div><div style={{fontSize:66,fontWeight:550,lineHeight:1.4,marginTop:18,whiteSpace:'pre-line',position:'relative'}}>{(titles[number]||s.title).replaceAll('\\n','\n')}</div>
 <div data-body style={{position:'absolute',left:80,right:80,top:389,height:672}}><Visual kind={s.kind} p/></div>
 <div data-method style={{position:'absolute',left:80,right:80,top:1110,fontSize:27,lineHeight:1.6,borderTop:'1px solid '+C.line,paddingTop:22,color:C.muted}}>{s.callout}</div>
 <div style={{position:'absolute',left:80,right:80,bottom:34,fontSize:22,color:C.muted}}>2026/10/01～11/06｜證交所・櫃買・期交所｜FlowScope 計算</div>
 </AbsoluteFill>}
export function Cover({portrait=false}:{portrait?:boolean}){return <AbsoluteFill style={{background:C.paper,color:C.ink,fontFamily:'Noto Sans TC',padding:portrait?'105px 85px':'76px 110px'}}>
 <PaperDetail portrait={portrait} cover/><Brand label="三市場觀察 EP.01" portrait={portrait}/>
 <div style={{marginTop:portrait?135:75,fontSize:portrait?27:30,color:C.gold,letterSpacing:4}}>MARKET NOTES　/　市場觀察筆記</div>
 <div style={{fontSize:portrait?94:110,fontWeight:500,lineHeight:1.5,letterSpacing:4,marginTop:portrait?38:22,position:'relative'}}>現股・期貨<br/>選擇權一起看</div>
 <div style={{width:75,height:3,background:'#A9C0AF',marginTop:portrait?55:30}}/>
 <div style={{fontSize:portrait?46:50,color:C.muted,lineHeight:1.65,marginTop:30,position:'relative'}}>台股走弱的這段時間<br/>籌碼透露了什麼？</div>
 <div style={{position:'absolute',left:portrait?85:110,bottom:portrait?180:80,fontSize:portrait?30:31,color:C.muted,lineHeight:1.8}}>2026/10/01～11/06<br/>24 個交易日・資料分析專題</div>
 </AbsoluteFill>}
export function Teaser(){let offset=0;const parts=content.teaserScenes.map(index=>{const s=timeline.scenes[index];const item={index,start:s.from,from:offset,duration:s.durationInFrames};offset+=s.durationInFrames;return item});const cc=parts.flatMap(p=>captions.filter(c=>c.startMs>=p.start/30*1000&&c.startMs<(p.start+p.duration)/30*1000).map(c=>({...c,startMs:c.startMs+(p.from-p.start)/30*1000,endMs:c.endMs+(p.from-p.start)/30*1000})));
 return <AbsoluteFill>{parts.map((s,j)=><Sequence key={s.index} from={s.from} durationInFrames={s.duration} name={'精華 '+(j+1)}><AbsoluteFill style={{background:C.paper,color:C.ink,fontFamily:'Noto Sans TC',padding:'105px 80px'}}><PaperDetail portrait/><Brand label="三市場觀察精華" portrait/><div style={{fontSize:72,lineHeight:1.5,fontWeight:550,marginTop:82,position:'relative'}}>期貨跟現股同步<br/>就能預測明天？</div><div style={{position:'absolute',left:80,right:80,top:510,height:790}}><Visual kind={content.scenes[s.index].kind} p/></div><div style={{position:'absolute',left:80,right:80,top:1380,fontSize:30,color:C.muted,lineHeight:1.6}}>2026/10/01～11/06｜24 個交易日<br/>{content.scenes[s.index].callout}</div><Audio src={staticFile(timeline.narration)} trimBefore={s.start} trimAfter={s.start+s.duration}/></AbsoluteFill></Sequence>)}<CaptionLayer portrait items={cc}/></AbsoluteFill>;
}
