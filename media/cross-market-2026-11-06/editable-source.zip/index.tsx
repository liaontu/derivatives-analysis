import React from 'react';
import {Composition,Still,Folder,registerRoot} from 'remotion';
import {Film,Card,Cover,Teaser} from './Film';
import timeline from './timeline.json';
import content from './content.json';
registerRoot(()=> <>
 <Composition id="CrossMarketEpisode" component={Film} width={1920} height={1080} fps={30} durationInFrames={timeline.durationInFrames}/>
 <Composition id="CrossMarketHighlights" component={Teaser} width={1080} height={1920} fps={30} durationInFrames={content.teaserScenes.reduce((n,i)=>n+timeline.scenes[i].durationInFrames,0)}/>
 <Still id="LandscapeCover" component={Cover} width={1920} height={1080}/>
 <Still id="PortraitCover" component={Cover} width={1080} height={1920} defaultProps={{portrait:true}}/>
 <Folder name="12-Cards">{content.cardScenes.map((_,i)=><Still key={i} id={'Card'+String(i+1).padStart(2,'0')} component={Card} width={1080} height={1350} defaultProps={{number:i+1}}/>)}</Folder>
</>);
