可重製的 Remotion 專案。Node 24；npm install；npm run studio；npm run render。
輸出在 exports。旁白已附；若改動旁白文句，須另行重錄並重建時間軸／字幕。
本機Qwen模型、Python環境、憑證與社群紀錄均未收錄。
資料為2026/11/06固定版本，原始報告與SHA-256另附。