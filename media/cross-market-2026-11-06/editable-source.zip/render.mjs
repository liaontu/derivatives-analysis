import {bundle} from '@remotion/bundler';
import {getCompositions,renderStill,renderMedia,openBrowser} from '@remotion/renderer';
import fs from 'node:fs/promises';import path from 'node:path';import {fileURLToPath} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));const out=path.join(root,'exports');await fs.mkdir(out,{recursive:true});
const serveUrl=await bundle({entryPoint:path.join(root,'index.tsx'),publicDir:path.join(root,'public'),outDir:path.join(root,'bundle')});
const browser=await openBrowser('chrome',{logLevel:'error'});
try{const comps=await getCompositions(serveUrl,{puppeteerInstance:browser});
 if(process.argv.includes('--cards')){
  for(let i=1;i<=12;i++){const id='Card'+String(i).padStart(2,'0');await renderStill({serveUrl,composition:comps.find(c=>c.id===id),output:path.join(out,`card-${String(i).padStart(2,'0')}.png`),imageFormat:'png',puppeteerInstance:browser,logLevel:'error'});console.log('CARD',i)}
  for(const id of ['LandscapeCover','PortraitCover'])await renderStill({serveUrl,composition:comps.find(c=>c.id===id),output:path.join(out,id+'.png'),imageFormat:'png',puppeteerInstance:browser,logLevel:'error'});
 }
 for(const [flag,id,file] of [['--video','CrossMarketEpisode','full-video.mp4'],['--teaser','CrossMarketHighlights','vertical-highlights.mp4']])if(process.argv.includes(flag)){
  let last=-1;await renderMedia({serveUrl,composition:comps.find(c=>c.id===id),outputLocation:path.join(out,file),codec:'h264',pixelFormat:'yuv420p',crf:20,concurrency:8,puppeteerInstance:browser,logLevel:'error',onProgress:({progress})=>{const step=Math.floor(progress*20);if(step!==last){last=step;console.log(id,step*5+'%',new Date().toISOString())}}});console.log('VIDEO_DONE',file);
 }
 if(process.argv.includes('--proofs')){const timeline=JSON.parse(await fs.readFile(path.join(root,'timeline.json'),'utf8'));await fs.mkdir(path.join(root,'proofs'),{recursive:true});for(const s of timeline.scenes){await renderStill({serveUrl,composition:comps.find(c=>c.id==='CrossMarketEpisode'),frame:s.from+Math.floor(s.durationInFrames*.45),output:path.join(root,'proofs',`scene-${String(s.index+1).padStart(2,'0')}.png`),imageFormat:'png',puppeteerInstance:browser,logLevel:'error'});console.log('PROOF',s.index+1)}}
}finally{await browser.close({silent:true})}
